export const restApiSettings = {
    // baseURL: process.env.REACT_APP_API_BASE_URL || 'https://babydogedefi.io:8443',
    // baseURL: process.env.REACT_APP_API_BASE_URL || 'https://saitamaswap.io:8443',
    baseURL: process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000',
    alterURL: process.env.REACT_APP_API_BASE_URL || 'https://safemoonswap.app',
}